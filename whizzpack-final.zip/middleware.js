import { NextResponse } from 'next/server';

/**
 * Middleware: serve original HTML files directly from public/ for main pages.
 * Blog pages (/blog/*) are handled by Next.js as usual.
 */
export function middleware(request) {
  const { pathname } = request.nextUrl;

  // Rewrite main pages to static HTML files in public/
  const htmlMap = {
    '/': '/index.html',
    '/corrugated-boxes': '/corrugated-boxes.html',
    '/cotton-seed-bags': '/cotton-seed-bags.html',
  };

  if (htmlMap[pathname]) {
    const url = request.nextUrl.clone();
    url.pathname = htmlMap[pathname];
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  // Only intercept these exact paths; let /blog/* and /_next/* pass through
  matcher: ['/', '/corrugated-boxes', '/cotton-seed-bags'],
};
