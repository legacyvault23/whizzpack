import Head from 'next/head';
import Script from 'next/script';

export default function Layout({ children, title, description, canonical, ogTitle, ogDesc, schema, navHtml, footerHtml }) {
  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={canonical} />
        <link rel="alternate" hrefLang="en" href={canonical} />
        <link rel="alternate" hrefLang="en-US" href={canonical} />
        <link rel="alternate" hrefLang="en-GB" href={canonical} />
        <link rel="alternate" hrefLang="x-default" href={canonical} />
        <meta property="og:title" content={ogTitle || title} />
        <meta property="og:description" content={ogDesc || description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonical} />
        <link rel="icon" type="image/png" href="/favicon.png" />
        <link rel="sitemap" type="application/xml" href="/sitemap.xml" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        {schema && (
          <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schema }} />
        )}
      </Head>
      {navHtml && <div dangerouslySetInnerHTML={{ __html: navHtml }} />}
      {children}
      {footerHtml && <div dangerouslySetInnerHTML={{ __html: footerHtml }} />}
      <Script id="blog-nav" strategy="afterInteractive">{`
        (function(){
          var hb=document.getElementById('hb'),mm=document.getElementById('mm');
          if(hb&&mm){
            hb.addEventListener('click',function(){var o=mm.classList.toggle('open');hb.classList.toggle('open',o);});
            mm.querySelectorAll('.mlink').forEach(function(l){l.addEventListener('click',function(){mm.classList.remove('open');hb.classList.remove('open');});});
          }
          var nav=document.getElementById('nav');
          if(nav){window.addEventListener('scroll',function(){nav.classList.toggle('scrolled',window.scrollY>60);},{passive:true});}
          document.querySelectorAll('.nav-dd').forEach(function(dd){
            var t=dd.querySelector('.nav-dd-toggle'),m=dd.querySelector('.dd-menu');
            if(!t||!m)return;
            t.addEventListener('click',function(e){e.preventDefault();m.classList.toggle('open');});
            document.addEventListener('click',function(e){if(!dd.contains(e.target))m.classList.remove('open');});
          });
        })();
      `}</Script>
    </>
  );
}
