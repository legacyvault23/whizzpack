import Link from 'next/link';
import Layout from '../../components/Layout';
import { getAllPosts } from '../../lib/posts';
import fs from 'fs';
import path from 'path';

export default function BlogIndex({ posts, navHtml, footerHtml }) {
  return (
    <Layout
      title="Packaging & Export Insights | Whizzpack Blog"
      description="Expert guides on importing corrugated boxes and cotton seed bags from India. Sourcing tips, shipping advice, and packaging insights for US & UK importers."
      canonical="https://www.whizzpack.in/blog"
      navHtml={navHtml}
      footerHtml={footerHtml}
    >

      <section className="blog-hero anim">
        <div className="wrap">
          <h1>Export &amp; Packaging Insights</h1>
          <p>Guides for US &amp; UK importers sourcing corrugated boxes and cotton seed bags from India.</p>
        </div>
      </section>

      <section style={{ background: 'var(--light)', minHeight: '60vh' }}>
        <div className="wrap">
          {posts.length === 0 ? (
            <p style={{ padding: '80px 0', textAlign: 'center', color: '#888' }}>Posts coming soon.</p>
          ) : (
            <div className="blog-grid">
              {posts.map(post => (
                <Link key={post.slug} href={`/blog/${post.slug}`} className="blog-card">
                  <div className="bc-img" style={{ background: 'var(--navy)' }}>
                    <svg width="64" height="64" viewBox="0 0 64 64" fill="none"><rect width="64" height="64" rx="8" fill="rgba(255,255,255,0.05)"/><path d="M16 20h32v4H16zM16 28h24v4H16zM16 36h20v4H16z" fill="rgba(240,90,40,0.7)"/></svg>
                  </div>
                  <div className="bc-body">
                    <div className="bc-tag">{post.tag}</div>
                    <div className="bc-title">{post.title}</div>
                    <p className="bc-excerpt">{post.excerpt}</p>
                    <div className="bc-meta">
                      <span>{new Date(post.date).toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' })}</span>
                      <span className="bc-read">{post.readTime} →</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}

export async function getStaticProps() {
  const posts = getAllPosts();
  const base = path.join(process.cwd(), 'page-content');
  const navHtml = fs.readFileSync(path.join(base, 'nav-sub.html'), 'utf-8');
  const footerHtml = fs.readFileSync(path.join(base, 'footer.html'), 'utf-8');
  return { props: { posts, navHtml, footerHtml } };
}
