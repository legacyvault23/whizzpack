import Link from 'next/link';
import Layout from '../../components/Layout';
import { getAllPosts, getPost } from '../../lib/posts';
import fs from 'fs';
import path from 'path';

export default function BlogPost({ post, navHtml, footerHtml }) {
  if (!post) return null;
  const canonicalUrl = `https://www.whizzpack.in/blog/${post.slug}`;

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": post.title,
    "description": post.excerpt,
    "datePublished": post.date,
    "author": { "@type": "Organization", "name": "Whizzpack", "url": "https://www.whizzpack.in" },
    "publisher": {
      "@type": "Organization",
      "name": "Whizzpack",
      "logo": { "@type": "ImageObject", "url": "https://www.whizzpack.in/favicon.png" }
    },
    "mainEntityOfPage": { "@type": "WebPage", "@id": canonicalUrl }
  };

  return (
    <Layout
      title={`${post.title} | Whizzpack`}
      description={post.excerpt}
      canonical={canonicalUrl}
      navHtml={navHtml}
      footerHtml={footerHtml}
    >

      <div style={{ background: 'var(--light)', minHeight: '100vh', paddingTop: '80px' }}>
        <div className="post-wrap">
          {/* Breadcrumb */}
          <nav style={{ fontSize: '.85rem', color: '#888', marginBottom: '32px' }}>
            <Link href="/" style={{ color: '#888', textDecoration: 'none' }}>Home</Link>
            {' / '}
            <Link href="/blog" style={{ color: '#888', textDecoration: 'none' }}>Blog</Link>
            {' / '}
            <span style={{ color: 'var(--navy)' }}>{post.title}</span>
          </nav>

          <div className="post-header">
            <div className="post-tag">{post.tag}</div>
            <h1 className="post-title">{post.title}</h1>
            <div className="post-meta">
              <span>{new Date(post.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
              <span>·</span>
              <span>{post.readTime}</span>
            </div>
          </div>

          <div className="post-body" dangerouslySetInnerHTML={{ __html: post.contentHtml }} />

          {/* CTA */}
          <div className="post-cta">
            <h3>Ready to Source from India?</h3>
            <p>Get factory-direct pricing on corrugated boxes and cotton seed bags. MOQ 5,000 units. We handle all export documentation.</p>
            <a href="/#contact">Request a Free Quote</a>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export async function getStaticPaths() {
  const posts = getAllPosts();
  return {
    paths: posts.map(p => ({ params: { slug: p.slug } })),
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const post = await getPost(params.slug);
  const base = path.join(process.cwd(), 'page-content');
  const navHtml = fs.readFileSync(path.join(base, 'nav-sub.html'), 'utf-8');
  const footerHtml = fs.readFileSync(path.join(base, 'footer.html'), 'utf-8');
  if (!post) return { notFound: true };
  return { props: { post, navHtml, footerHtml } };
}
